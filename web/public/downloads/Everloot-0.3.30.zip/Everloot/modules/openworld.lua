-- Everloot open-world collector: NPC sightings, loot windows, quests, vendors, items seen, minimap vignettes,
-- dungeon entrances, boss encounters with their length, and dungeon and raid runs.
-- Anonymous by design: no character or guild names, no player chat. Matches the intake contract
-- (web/src/lib/intake.ts kinds: npc_sighting, loot, quest, vendor, item_seen, object_sighting, instance_entrance,
-- encounter, instance_run). The one chat event it reads is CHAT_MSG_SYSTEM, for the game's own instance reset line.
-- NPC type, rank and a quest's category, group size, tag and faction are game facts about the NPC or quest.
-- The faction is the accepting character's side only; no character name is read or stored.

local E = Everloot

local function mapPosition()
  if C_Map and C_Map.GetPlayerMapPosition and C_Map.GetBestMapForUnit then
    local mapId = E.Readable(C_Map.GetBestMapForUnit("player"))
    if not mapId then return nil end
    local pos = C_Map.GetPlayerMapPosition(mapId, "player")
    local x, y = pos and E.Readable(pos.x), pos and E.Readable(pos.y)
    if not x or not y then return { mapId = mapId } end
    return { mapId = mapId, x = x * 100, y = y * 100 }
  end
  return nil
end

local npcIdFromGuid = E.NpcIdFromGuid

-- The object id in a game object GUID (GameObject-0-server-instance-zone-ID-spawn); nil for anything else.
local function objectIdFromGuid(guid)
  guid = E.Readable(guid)
  return type(guid) == "string" and tonumber(guid:match("^GameObject%-%d+%-%d+%-%d+%-%d+%-(%d+)%-")) or nil
end

-- True for an item GUID (Item-server-0-id): a disenchanted item or an opened container. The GUID does not hold
-- the item's id; see itemIdFromGuid.
local function isItemGuid(guid)
  guid = E.Readable(guid)
  return type(guid) == "string" and guid:find("^Item%-") ~= nil
end

-- A whole number from lo to hi, else nil.
local function whole(v, lo, hi)
  if type(v) == "number" and v == math.floor(v) and v >= lo and v <= hi then return v end
  return nil
end
local MAX_ID = 9007199254740991

-- The English creature types the protocol accepts. A localized client names them in its own language and
-- they do not match, so no type is recorded there rather than a guess.
local CREATURE_TYPES = {}
for _, t in ipairs({ "Beast", "Dragonkin", "Demon", "Elemental", "Giant", "Undead", "Humanoid", "Critter",
  "Mechanical", "Not specified", "Totem", "Non-combat Pet", "Gas Cloud" }) do CREATURE_TYPES[t] = true end

-- UnitClassification: trivial and minus are left out, they are not ranks a player looks up.
local RANKS = { normal = "normal", elite = "elite", rare = "rare", rareelite = "rare_elite", worldboss = "boss" }

local function creatureTraits(unit)
  local creatureType, rank
  if UnitCreatureType then
    local ok, t = pcall(UnitCreatureType, unit)
    if ok and type(t) == "string" and CREATURE_TYPES[t] then creatureType = t end
  end
  if UnitClassification then
    local ok, c = pcall(UnitClassification, unit)
    if ok and type(c) == "string" then rank = RANKS[c] end
  end
  return creatureType, rank
end

-- Each share of a kind has its own cap, so targeting and corpses cannot use up the room that NPC windows
-- and object positions need. Rows keep their kind and shape; the share is read from the row.
local function sightingShare(row)
  return (row.positionKind == "interaction" or row.positionKind == "vignette") and row.positionKind or "targeting"
end
local function lootShare(row) return row.sourceItemId and "items" or row.sourceObjectId and "objects" or "creatures" end
local TARGETING = { name = "targeting", of = sightingShare }
local INTERACTION = { name = "interaction", of = sightingShare }
local VIGNETTE = { name = "vignette", of = sightingShare }
local OBJECTS = { name = "objects", of = lootShare }
local CREATURES = { name = "creatures", of = lootShare }
local ITEMS = { name = "items", of = lootShare }

local function targetSighting(unit)
  local guid = UnitGUID(unit)
  local npcId = npcIdFromGuid(guid)
  if not npcId then return end
  local name = E.Readable(UnitName(unit))
  local level = E.Readable(UnitLevel(unit))
  if not name or not level or level < 1 then return end
  local where = mapPosition()
  if not where or not where.x or not where.y then return end
  -- One row per NPC, zone and spot (rounded to 1 on the 0..100 scale): retargeting the same NPC adds nothing.
  EverlootDB.targetSeen = EverlootDB.targetSeen or {}
  local seenKey = npcId .. ":" .. where.mapId .. ":" .. math.floor(where.x + 0.5) .. ":" .. math.floor(where.y + 0.5)
  if EverlootDB.targetSeen[seenKey] then return end
  local reaction = "neutral"
  if E.Readable(UnitIsFriend("player", unit)) then reaction = "friendly"
  elseif E.Readable(UnitCanAttack("player", unit)) then reaction = "hostile" end
  local creatureType, rank = creatureTraits(unit)
  local stored = E:Store("npc_sighting", {
    installId = EverlootDB.installId,
    capturedAt = date("!%Y-%m-%dT%H:%M:%SZ"),
    npcId = npcId, name = name,
    mapId = where.mapId, x = where.x, y = where.y, positionKind = "player",
    level = level, reaction = reaction,
    creatureType = creatureType, rank = rank,
  }, nil, TARGETING)
  if stored then EverlootDB.targetSeen[seenKey] = true end
end

-- NPC windows. While one is open the player stands within a few yards of the NPC that opened it, so the
-- player's position is recorded as the NPC's (positionKind "interaction") with the window's role. A gossip
-- window names no service; its role comes from the old gossip option types when the client has them.
-- Event names that were not checked on the Forever client are registered under pcall: one that never
-- fires records nothing.
local WINDOW_ROLES = {
  MERCHANT_SHOW = "vendor", TRAINER_SHOW = "trainer", QUEST_DETAIL = "questgiver", QUEST_GREETING = "questgiver",
  TAXIMAP_OPENED = "flightmaster", BANKFRAME_OPENED = "banker", AUCTION_HOUSE_SHOW = "auctioneer",
  PET_STABLE_SHOW = "stablemaster", CONFIRM_BINDER = "innkeeper", GOSSIP_SHOW = false,
}
-- The newer clients' PLAYER_INTERACTION_MANAGER_FRAME_SHOW, by Enum.PlayerInteractionType name.
local INTERACTION_ROLES = {
  Merchant = "vendor", Trainer = "trainer", QuestGiver = "questgiver", TaxiNode = "flightmaster", Banker = "banker",
  Auctioneer = "auctioneer", StableMaster = "stablemaster", Binder = "innkeeper", Gossip = false,
}

local function interactionRole(kind)
  local types = Enum and Enum.PlayerInteractionType
  if type(types) ~= "table" or kind == nil then return nil end
  for name, role in pairs(INTERACTION_ROLES) do
    if types[name] == kind then return role end
  end
  return nil
end

local function gossipRole()
  if not GetGossipOptions then return false end
  local options = { pcall(GetGossipOptions) }
  if not options[1] then return false end
  -- Old clients return text, type, text, type: "binder" is an innkeeper.
  for i = 3, #options, 2 do
    if options[i] == "binder" then return "innkeeper" end
  end
  return false
end

local function interactionSighting(role)
  local unit = "npc"
  local npcId = npcIdFromGuid(UnitGUID(unit))
  if not npcId and role == "questgiver" then
    unit = "questnpc"
    npcId = npcIdFromGuid(UnitGUID(unit))
  end
  if not npcId then return end
  if role == "vendor" and CanMerchantRepair then
    local ok, repairs = pcall(CanMerchantRepair)
    if ok and repairs then role = "repair" end
  end
  local name, level = E.Readable(UnitName(unit)), E.Readable(UnitLevel(unit))
  if type(name) ~= "string" or name == "" or type(level) ~= "number" or level < 1 or level > 100 then return end
  local where = mapPosition()
  if not where or not where.x or not where.y then return end
  EverlootDB.interactionSeen = EverlootDB.interactionSeen or {}
  local seenKey = npcId .. ":" .. (role or "") .. ":" .. where.mapId
  if EverlootDB.interactionSeen[seenKey] then return end
  local reaction = "neutral"
  if E.Readable(UnitIsFriend("player", unit)) then reaction = "friendly"
  elseif E.Readable(UnitCanAttack("player", unit)) then reaction = "hostile" end
  local creatureType, rank = creatureTraits(unit)
  local stored = E:Store("npc_sighting", {
    installId = EverlootDB.installId,
    capturedAt = date("!%Y-%m-%dT%H:%M:%SZ"),
    npcId = npcId, name = name:sub(1, 120),
    mapId = where.mapId, x = where.x, y = where.y, positionKind = "interaction", role = role or nil,
    level = level, reaction = reaction,
    creatureType = creatureType, rank = rank,
  }, nil, INTERACTION)
  if stored then EverlootDB.interactionSeen[seenKey] = true end
end

-- The spell cast on an object, read at UNIT_SPELLCAST_SENT just before its loot window opens. English names
-- and the Classic spell ids; any other spell is "other". The cast's target is the object's name, kept only for
-- herb, ore and chest casts: any other spell's target may be a player, and a player's name never goes on a row.
local GATHER_BY_NAME = {
  ["Herb Gathering"] = "herb", ["Mining"] = "ore", ["Opening"] = "chest", ["Opening - No Text"] = "chest",
  ["Fishing"] = "fishing",
}
local GATHER_BY_ID = {
  [2366] = "herb", [2368] = "herb", [3570] = "herb", [11993] = "herb",
  [2575] = "ore", [2576] = "ore", [3564] = "ore", [10248] = "ore",
  [3365] = "chest", [6247] = "chest", [6477] = "chest", [6478] = "chest", [21651] = "chest", [22810] = "chest",
  [7620] = "fishing", [7731] = "fishing", [7732] = "fishing", [18248] = "fishing",
}
-- The same cast also types a window on a creature or an item (loot tables spec, section 4): pick-pocketing and
-- skinning open a second window on the creature's GUID, disenchanting and picking a lock name an item. Only the
-- spell's English name or Classic id decides it; the cast's target is never kept for these.
local LOOT_BY_NAME = { ["Pick Pocket"] = "pickpocket", ["Skinning"] = "skinning", ["Disenchant"] = "disenchant", ["Pick Lock"] = "container" }
local LOOT_BY_ID = {
  [921] = "pickpocket", [8613] = "skinning", [8617] = "skinning", [8618] = "skinning", [10768] = "skinning",
  [13262] = "disenchant", [1804] = "container",
}
-- The skill lines a gathering cast uses, by the game files' SkillLine ids: Herbalism, Mining, Skinning.
local GATHER_SKILL_LINES = { herb = 182, ore = 186, skinning = 393 }
-- A loot window more than this many seconds after the cast is not that cast's. A fish can take longer to bite.
local GATHER_WINDOW, FISHING_WINDOW = 8, 30
local NAMED_KINDS = { herb = true, ore = true, chest = true }
local lastCast

-- True when the name is the targeted player's: such a cast target is never kept.
local function targetPlayerNamed(name)
  if not (UnitName and UnitIsPlayer) then return false end
  local okPlayer, isPlayer = pcall(UnitIsPlayer, "target")
  if not okPlayer or not isPlayer then return false end
  local okName, targetName = pcall(UnitName, "target")
  return okName and targetName == name
end

local function now()
  if not GetTime then return nil end
  local ok, t = pcall(GetTime)
  return ok and type(t) == "number" and t or nil
end

local function spellName(spellId)
  if C_Spell and C_Spell.GetSpellName then
    local ok, name = pcall(C_Spell.GetSpellName, spellId)
    if ok and type(name) == "string" then return name end
  end
  if GetSpellInfo then
    local ok, info = pcall(GetSpellInfo, spellId)
    if ok and type(info) == "table" then info = info.name end
    if ok and type(info) == "string" then return info end
  end
  return nil
end

-- Newer clients send unit, target, castGUID, spellID; old ones unit, spell name, rank, target.
local function castSent(unit, a2, a3, a4)
  if unit ~= "player" then return end
  local spellId, name, target
  if type(a4) == "number" then spellId, target = a4, a2
  elseif type(a2) == "string" then name, target = a2, a4 end
  local spell = name or (spellId and spellName(spellId)) or ""
  local kind = (spellId and GATHER_BY_ID[spellId]) or GATHER_BY_NAME[spell] or "other"
  local lootKind = (spellId and LOOT_BY_ID[spellId]) or LOOT_BY_NAME[spell]
  -- Disenchanting and picking a lock target an item by name: its id is read now, while the item is in the bags.
  local itemId
  if (lootKind == "disenchant" or lootKind == "container") and type(target) == "string" and target ~= "" then
    local info = C_Item and C_Item.GetItemInfoInstant or GetItemInfoInstant
    local ok, id = pcall(info or error, target)
    itemId = ok and whole(id, 1, 10000000) or nil
  end
  if not NAMED_KINDS[kind] or type(target) ~= "string" or target == "" or #target > 120 or targetPlayerNamed(target) then
    target = nil
  end
  lastCast = { gatherKind = kind, lootKind = lootKind, itemId = itemId, name = target, at = now(),
    castGuid = spellId and type(a3) == "string" and a3 or nil }
end

-- True when a cast event is for the pending cast: by cast GUID where both have one, else any cast of the player's.
local function pendingCast(castGuid)
  if not lastCast then return false end
  if lastCast.castGuid and type(castGuid) == "string" and castGuid:find("^Cast%-") then return lastCast.castGuid == castGuid end
  return true
end

local function gatherContext()
  local cast = lastCast
  lastCast = nil
  if not cast then return nil end
  local t = now()
  local window = cast.gatherKind == "fishing" and FISHING_WINDOW or GATHER_WINDOW
  if cast.at and t and t - cast.at > window then return nil end
  -- A creature or item type needs the cast to have succeeded; an instant Pick Pocket may also count for 2 seconds
  -- after it was sent. A cast that failed or was interrupted never gets here (it clears lastCast).
  if cast.lootKind and not cast.succeeded and not (cast.lootKind == "pickpocket" and cast.at and t and t - cast.at <= 2) then
    cast.lootKind, cast.itemId = nil, nil
  end
  return cast
end

-- Quest tags by the game's own Enum.QuestTag names; a client without the enum records no tag.
local function questTag(questId)
  local info = C_QuestLog and C_QuestLog.GetQuestTagInfo
  local tags = Enum and Enum.QuestTag
  if not info or not tags then return nil end
  local ok, tagInfo = pcall(info, questId)
  local id = ok and type(tagInfo) == "table" and tagInfo.tagID
  if not id then return nil end
  if id == tags.Dungeon then return "dungeon" end
  if id == tags.Raid then return "raid" end
  if id == tags.PvP then return "pvp" end
  if id == tags.Group then return "group" end
  return nil
end

--- One quest log row: title, level, suggested group, isHeader, quest id. Older clients have GetQuestLogTitle;
--- Forever's client (mainline UI) has only C_QuestLog.GetInfo, which returns the same fields as a table.
local function questLogRow(index)
  if GetQuestLogTitle then
    local ok, title, level, group, isHeader, _, _, _, logId = pcall(GetQuestLogTitle, index)
    if ok then return title, level, group, isHeader, logId end
    return nil
  end
  if not (C_QuestLog and C_QuestLog.GetInfo) then return nil end
  local ok, info = pcall(C_QuestLog.GetInfo, index)
  info = ok and E.Readable(info)
  if type(info) ~= "table" then return nil end
  return E.Readable(info.title), E.Readable(info.level), E.Readable(info.suggestedGroup), E.Readable(info.isHeader), E.Readable(info.questID)
end

local function canReadQuestLog()
  return GetQuestLogTitle ~= nil or (C_QuestLog ~= nil and C_QuestLog.GetInfo ~= nil and C_QuestLog.GetLogIndexForQuestID ~= nil)
end

-- A quest the character just accepted, read from its own quest log row. Level is the quest's level as the log
-- shows it; a row that is not this quest, or has no real level, records nothing.
-- QUEST_ACCEPTED gives (log index, quest id) on older clients and only the quest id on Forever's.
local function questCapture(arg1, arg2)
  local index, questId = arg1, arg2
  if questId == nil then index, questId = nil, E.Readable(arg1) end
  if not canReadQuestLog() or type(questId) ~= "number" then return end
  if index == nil and C_QuestLog and C_QuestLog.GetLogIndexForQuestID then
    local ok, found = pcall(C_QuestLog.GetLogIndexForQuestID, questId)
    index = ok and E.Readable(found) or nil
  end
  if type(index) ~= "number" then return end
  local faction = UnitFactionGroup and UnitFactionGroup("player")
  faction = faction == "Alliance" and "alliance" or faction == "Horde" and "horde" or nil
  EverlootDB.questSeen = EverlootDB.questSeen or {}
  local seenKey = tostring(questId) .. ":" .. tostring(faction)
  if EverlootDB.questSeen[seenKey] then return end
  local title, level, group, isHeader, logId = questLogRow(index)
  if isHeader or logId ~= questId or type(title) ~= "string" or title == "" then return end
  if type(level) ~= "number" or level < 1 or level ~= math.floor(level) then return end
  -- The category is the nearest header above the quest in the log.
  local category
  for i = index - 1, 1, -1 do
    local name, _, _, header = questLogRow(i)
    if header and type(name) == "string" and name ~= "" then category = name:sub(1, 60); break end
  end
  local row = {
    installId = EverlootDB.installId,
    capturedAt = date("!%Y-%m-%dT%H:%M:%SZ"),
    questId = questId, title = title:sub(1, 200), level = level, rewardItemIds = {},
    category = category, faction = faction, tag = questTag(questId),
  }
  -- A number here is the suggested group size; some clients return a tag string in this place.
  if type(group) == "number" and group >= 2 and group <= 40 and group == math.floor(group) then row.suggestedGroup = group end
  -- The giver is the NPC whose window is open; nothing is recorded for an item, an object or a shared quest.
  row.giverNpcId = npcIdFromGuid(UnitGUID("npc")) or npcIdFromGuid(UnitGUID("questnpc"))
  if E:Store("quest", row) then EverlootDB.questSeen[seenKey] = true end
end

local QUALITY = {
  [0] = "poor", [1] = "common", [2] = "uncommon", [3] = "rare",
  [4] = "epic", [5] = "legendary", [6] = "artifact", [7] = "heirloom",
}

local function rememberItem(itemId)
  if not GetItemInfo then return end
  local name, _, quality, level, _, _, _, _, _, _, _, class = GetItemInfo(itemId)
  local label = QUALITY[quality]
  -- An item the client has not cached yet answers with a stand-in name, which is not the item's name.
  if not name or not label or name:find("^Item %d+$") then return end
  -- Armor and weapons (class 4 and 2) carry their item level: the site sorts a disenchanted piece into its band by
  -- it when the game files give the item no level. Other items do not need it.
  level = E.Readable(level)
  local gear = (E.Readable(class) == 2 or E.Readable(class) == 4) and type(level) == "number" and level >= 1
    and level <= 1000 and level == math.floor(level)
  -- One row per item: the same item in another loot window or on another vendor adds nothing. A new row is
  -- stored only when the client shows a different name, quality or (for gear) item level for it.
  EverlootDB.itemSeenIds = EverlootDB.itemSeenIds or {}
  local seen = label .. " " .. name .. (gear and (" " .. level) or "")
  if EverlootDB.itemSeenIds[itemId] == seen then return end
  local stored = E:Store("item_seen", {
    installId = EverlootDB.installId,
    capturedAt = date("!%Y-%m-%dT%H:%M:%SZ"),
    itemId = itemId, name = name, quality = label, itemLevel = gear and level or nil,
  })
  if stored then EverlootDB.itemSeenIds[itemId] = seen end
end

-- The copper in loot slot i when it is the coin slot, read from the slot's text; nil for an item slot or a text
-- that holds no amount.
local function slotCopper(i, text)
  text = E.Readable(text)
  local slotType = GetLootSlotType and select(2, pcall(GetLootSlotType, i))
  if slotType ~= (Enum and Enum.LootSlotType and Enum.LootSlotType.Money or LOOT_SLOT_MONEY or 2) or type(text) ~= "string" then
    return nil
  end
  local total = E.CoinText(text)
  return total and total <= 10000000000 and total or nil
end

-- The id of the item an item GUID names. The GUID itself does not hold it: the disenchant or lock cast read it
-- from the target's name, and an item opened with no cast is looked up by its GUID. Nil when neither works.
local function itemIdFromGuid(guid, cast)
  if cast and cast.itemId and (cast.lootKind == "disenchant" or cast.lootKind == "container") then return cast.itemId end
  if not C_Item then return nil end
  if C_Item.GetItemIDByGUID then
    local ok, id = pcall(C_Item.GetItemIDByGUID, guid)
    if ok and whole(id, 1, 10000000) then return id end
  end
  if C_Item.GetItemLocation and C_Item.GetItemID then
    local okLoc, location = pcall(C_Item.GetItemLocation, guid)
    local ok, id = pcall(C_Item.GetItemID, location)
    if okLoc and location and ok and whole(id, 1, 10000000) then return id end
  end
  return nil
end

-- What opened the window, from the source and the cast just before it. A creature's skinning window shares its
-- GUID with the kill; an item is disenchanted or opened as a container.
local function lootTypeOf(group, cast)
  local lootKind, gatherKind = cast and cast.lootKind, cast and cast.gatherKind
  if group.itemGuid then return lootKind == "disenchant" and "disenchant" or "container" end
  if group.sourceObjectId then return gatherKind == "fishing" and "fishing" or "gather" end
  if lootKind == "pickpocket" then return "pickpocket" end
  if lootKind == "skinning" or gatherKind == "herb" or gatherKind == "ore" then return "skinning" end
  return "kill"
end

-- The player's own rank in the gathering skill the cast used, read the way the game's profession book reads it:
-- GetProfessions, then the rank, skill line and rank bonus GetProfessionInfo gives. The value is rank plus bonus
-- (race, gear), what a node's requirement is checked against and what the book shows as "rank (+bonus)". Nil when the
-- cast was no gathering cast or the client cannot say; never guessed.
local function gatherSkill(cast)
  local skillLine = cast and (cast.lootKind == "skinning" and GATHER_SKILL_LINES.skinning or GATHER_SKILL_LINES[cast.gatherKind])
  if not skillLine or type(GetProfessions) ~= "function" or type(GetProfessionInfo) ~= "function" then return nil end
  -- Five slots (two professions, then the secondary ones); one the character has not filled is nil.
  local got = { pcall(GetProfessions) }
  if not got[1] then return nil end
  for slot = 2, 6 do
    local index = E.Readable(got[slot])
    if type(index) == "number" then
      local ok, _, _, rank, _, _, _, line, bonus = pcall(GetProfessionInfo, index)
      if ok and E.Readable(line) == skillLine then
        rank, bonus = E.Readable(rank), E.Readable(bonus)
        if type(rank) ~= "number" then return nil end
        -- A bonus the client cannot read counts as none: the trained rank is still a true lower bound.
        return whole(rank + (type(bonus) == "number" and bonus > 0 and bonus or 0), 1, 500)
      end
    end
  end
  return nil
end

-- The units an empty window can have come from: the corpse the player interacted with, pointed at or targeted.
local EMPTY_WINDOW_UNITS = { "softinteract", "mouseover", "target" }

-- The corpse of an empty window, or nil. The loot API names sources by slot, so a window with no slot names none.
-- The corpse is then the one dead creature among these units that the player may loot (not tap-denied). Two
-- different ones, a client without UnitIsDead or UnitIsTapDenied, or a GUID it cannot read: nil, and nothing is
-- recorded.
local function emptyWindowCorpse()
  if not (UnitGUID and UnitIsDead and UnitIsTapDenied) then return nil end
  local found
  for _, unit in ipairs(EMPTY_WINDOW_UNITS) do
    local okGuid, raw = pcall(UnitGUID, unit)
    -- A unit that is absent reads nil and is skipped; one whose GUID errors or is secret stops the guess, since it
    -- may be the corpse that opened the window while another unit names a different one.
    if not okGuid then return nil end
    local guid = E.Readable(raw)
    if raw ~= nil and guid == nil then return nil end
    if type(guid) == "string" and guid:find("^Creature%-") and npcIdFromGuid(guid) then
      local okDead, dead = pcall(UnitIsDead, unit)
      local okTap, denied = pcall(UnitIsTapDenied, unit)
      if okDead and E.Readable(dead) == true and okTap and E.Readable(denied) == false then
        if found and found ~= guid then return nil end
        found = guid
      end
    end
  end
  return found
end

-- A kill window with nothing in it: one row with no items and no coin, `sourceEvidence = "empty-window"`, so the
-- corpse counts in its source's windows and a drop rate stops leaving out the kills that dropped nothing. Only a
-- plain kill window: not an item, fishing, or a gathering or loot cast (skinning, pick-pocket, herb, ore, chest), and
-- one row per corpse. Any other cast (a combat spell just before looting) is `gatherKind = "other"` and still counts.
local function emptyWindowCapture(cast, isFromItem)
  if isFromItem or (cast and (cast.lootKind or (cast.gatherKind and cast.gatherKind ~= "other"))) then return end
  if IsFishingLoot then
    local ok, fishing = pcall(IsFishingLoot)
    if not ok or E.Readable(fishing) ~= false then return end
  end
  local guid = emptyWindowCorpse()
  if not guid then return end
  if EverlootDB.lootSources[guid .. ":kill"] or EverlootDB.lootSources[guid] then return end
  local row = {
    installId = EverlootDB.installId,
    capturedAt = date("!%Y-%m-%dT%H:%M:%SZ"),
    sourceNpcId = npcIdFromGuid(guid),
    lootType = "kill",
    items = {},
    sourceEvidence = "empty-window",
  }
  if E:Store("loot", row, nil, CREATURES) then EverlootDB.lootSources[guid .. ":kill"] = true end
end

local function lootCapture(_, isFromItem)
  -- Source pairs are GUID, quantity, GUID, quantity. Never infer loot from the target, except for a window with
  -- nothing in it, which has no source to read (emptyWindowCapture).
  if not (GetLootSourceInfo and GetLootSlotInfo and GetLootSlotLink) then return end
  local cast = gatherContext()
  EverlootDB.lootSources = EverlootDB.lootSources or {}
  if (GetNumLootItems and GetNumLootItems() or 0) == 0 then return emptyWindowCapture(cast, isFromItem) end
  local groups = {}
  local function groupFor(guid)
    local npcId, objectId = npcIdFromGuid(guid), objectIdFromGuid(guid)
    local itemGuid = not npcId and not objectId and isItemGuid(guid) and guid or nil
    if not (npcId or objectId or itemGuid) then return nil end
    groups[guid] = groups[guid] or { sourceNpcId = npcId, sourceObjectId = objectId, itemGuid = itemGuid, items = {} }
    return groups[guid]
  end
  local n = GetNumLootItems and GetNumLootItems() or 0
  for i = 1, math.min(n, 50) do
    local okLink, link = pcall(GetLootSlotLink, i)
    local okInfo, _, slotText, count = pcall(GetLootSlotInfo, i)
    if not okLink or not okInfo or type(link) ~= "string" then link = nil end
    local itemId = link and tonumber(link:match("item:(%d+)"))
    local copper = not link and okInfo and slotCopper(i, slotText) or nil
    if (itemId and type(count) == "number" and count > 0) or copper then
      local sources = { pcall(GetLootSourceInfo, i) }
      local coinSources, shared = {}, 0
      if sources[1] then
        for j = 2, #sources, 2 do
          local guid, quantity = sources[j], sources[j + 1]
          if copper then
            local group = groupFor(guid)
            if group and type(quantity) == "number" then coinSources[#coinSources + 1] = { group, quantity } end
          elseif type(quantity) == "number" and quantity >= 1 and quantity <= 1000 and quantity == math.floor(quantity) then
            local group = groupFor(guid)
            if group then group.items[#group.items + 1] = { itemId = itemId, count = quantity } end
          end
        end
      end
      -- Coin shared by several sources is split only when the per-source amounts add up to the slot's.
      for _, source in ipairs(coinSources) do shared = shared + source[2] end
      if #coinSources == 1 then coinSources[1][1].copper = copper
      elseif #coinSources > 1 and shared == copper then
        for _, source in ipairs(coinSources) do source[1].copper = source[2] end
      end
      if itemId then rememberItem(itemId) end
    end
  end
  local where
  for guid, group in pairs(groups) do
    local lootType = lootTypeOf(group, cast)
    -- Windows from before the type existed were keyed by the GUID alone, and were kill or gathering windows.
    local skip = EverlootDB.lootSources[guid .. ":" .. lootType]
      or (EverlootDB.lootSources[guid] and (lootType == "kill" or lootType == "gather" or lootType == "fishing"))
    if group.itemGuid then group.sourceItemId = itemIdFromGuid(group.itemGuid, cast) end
    -- An item whose id cannot be read, or a source with nothing in it, records nothing.
    if (group.itemGuid and not group.sourceItemId) or (#group.items == 0 and not group.copper) then skip = true end
    if not skip then
      group.itemGuid = nil
      group.lootType = lootType
      -- An object stays where it is: the player's position, how it was opened and its name go with it. A kill
      -- window carries the player's position too, which places the mob's zone. No position (an instance, no map)
      -- sends none.
      if group.sourceObjectId or (group.sourceNpcId and lootType == "kill") then
        if where == nil then
          local ok, pos = pcall(mapPosition)
          where = ok and pos and pos.x and pos.y and pos or false
        end
        if where then group.mapId, group.x, group.y = where.mapId, where.x, where.y end
      end
      if group.sourceObjectId and cast then group.gatherKind, group.sourceObjectName = cast.gatherKind, cast.name end
      -- A herb, ore or skinning window carries the player's rank in that skill.
      if lootType == "gather" or lootType == "skinning" then group.gatherSkill = gatherSkill(cast) end
      group.installId = EverlootDB.installId
      group.capturedAt = date("!%Y-%m-%dT%H:%M:%SZ")
      group.sourceEvidence = "loot-api"
      if lootType == "disenchant" then
        -- The item destroyed: its level places the disenchant in its band when the game files give it none.
        rememberItem(group.sourceItemId)
        if E.Disenchant then E.Disenchant.Record(group.sourceItemId, group.items, guid) end
      end
      if E:Store("loot", group, nil, group.sourceItemId and ITEMS or group.sourceObjectId and OBJECTS or CREATURES) then
        -- Local-only corpse identity, by GUID and loot type so a kill and a skinning window on one corpse are both
        -- kept: retained across reloads, never exported as a row.
        -- Bounded by the same retained loot-row capacity; failures do not mark seen.
        EverlootDB.lootSources[guid .. ":" .. lootType] = true
      end
    end
  end
end

-- GetInstanceInfo: name, instanceType, difficultyID, ..., the 8th return is the instance's map id (a map, not a
-- UiMap), the 10th a dungeon finder id. Nil when the call is missing or fails.
local function instanceInfo()
  if not GetInstanceInfo then return nil end
  local ok, name, instanceType, difficulty, _, _, _, _, instanceMapId, _, lfgDungeonId = pcall(GetInstanceInfo)
  if not ok then return nil end
  return { name = name, instanceType = instanceType, difficulty = difficulty, instanceMapId = instanceMapId,
    lfgDungeonId = lfgDungeonId }
end

-- Vignettes: a rare or a treasure the minimap shows, at its own position as the game's vignette API gives it, not
-- the player's. A creature becomes an npc_sighting with positionKind "vignette", a game object an object_sighting.
local function vignetteSighting(guid)
  local api = C_VignetteInfo
  if type(guid) ~= "string" or not (api and api.GetVignetteInfo and api.GetVignettePosition) then return end
  if not (C_Map and C_Map.GetBestMapForUnit) then return end
  local info = api.GetVignetteInfo(guid)
  if type(info) ~= "table" then return end
  local npcId = npcIdFromGuid(info.objectGUID)
  local objectId = not npcId and objectIdFromGuid(info.objectGUID)
  local name = info.name
  if not (npcId or objectId) or type(name) ~= "string" or name == "" or #name > 120 then return end
  local mapId = whole(C_Map.GetBestMapForUnit("player"), 0, MAX_ID)
  if not mapId then return end
  local pos = api.GetVignettePosition(guid, mapId)
  local x, y = type(pos) == "table" and pos.x, type(pos) == "table" and pos.y
  if type(x) ~= "number" or type(y) ~= "number" or x < 0 or x > 1 or y < 0 or y > 1 then return end
  x, y = x * 100, y * 100
  EverlootDB.vignetteSeen = EverlootDB.vignetteSeen or {}
  local seenKey = (npcId and "npc:" .. npcId or "object:" .. objectId) .. ":" .. mapId .. ":"
    .. math.floor(x + 0.5) .. ":" .. math.floor(y + 0.5)
  if EverlootDB.vignetteSeen[seenKey] then return end
  local stored
  if npcId then
    stored = E:Store("npc_sighting", {
      installId = EverlootDB.installId,
      capturedAt = date("!%Y-%m-%dT%H:%M:%SZ"),
      npcId = npcId, name = name, mapId = mapId, x = x, y = y, positionKind = "vignette",
    }, nil, VIGNETTE)
  else
    local inside = instanceInfo()
    stored = E:Store("object_sighting", {
      installId = EverlootDB.installId,
      capturedAt = date("!%Y-%m-%dT%H:%M:%SZ"),
      objectId = objectId, name = name, mapId = mapId, x = x, y = y,
      instanceMapId = inside and inside.instanceType ~= "none" and whole(inside.instanceMapId, 1, MAX_ID) or nil,
    })
  end
  if stored then EverlootDB.vignetteSeen[seenKey] = true end
end

local function vignettesUpdated()
  local api = C_VignetteInfo
  if not (api and api.GetVignettes) then return end
  local guids = api.GetVignettes()
  if type(guids) ~= "table" then return end
  for _, guid in ipairs(guids) do pcall(vignetteSighting, guid) end
end

-- Dungeon and raid entrances. The loading screen into an instance starts outdoors: PLAYER_LEAVING_WORLD keeps the
-- player's position there, and PLAYER_ENTERING_WORLD inside a dungeon or raid records it as the entrance. A dungeon
-- finder teleport starts anywhere, so it records nothing.
local outside

local function leavingWorld()
  outside = nil
  local info = instanceInfo()
  if not info or info.instanceType ~= "none" then return end
  local where = mapPosition()
  if where and where.x and where.y then outside = where end
end

local function enteringWorld()
  local from = outside
  outside = nil
  local info = instanceInfo()
  if not from or not info or (info.instanceType ~= "party" and info.instanceType ~= "raid") then return end
  if type(info.lfgDungeonId) == "number" and info.lfgDungeonId > 0 then return end
  local instanceMapId = whole(info.instanceMapId, 1, MAX_ID)
  local name = info.name
  if not instanceMapId or type(name) ~= "string" or name == "" or #name > 120 then return end
  if from.x < 0 or from.x > 100 or from.y < 0 or from.y > 100 then return end
  EverlootDB.entranceSeen = EverlootDB.entranceSeen or {}
  local seenKey = instanceMapId .. ":" .. from.mapId
  if EverlootDB.entranceSeen[seenKey] then return end
  if E:Store("instance_entrance", {
    installId = EverlootDB.installId,
    capturedAt = date("!%Y-%m-%dT%H:%M:%SZ"),
    instanceMapId = instanceMapId, name = name, instanceType = info.instanceType,
    difficulty = whole(info.difficulty, 0, 255),
    mapId = from.mapId, x = from.x, y = from.y,
  }) then EverlootDB.entranceSeen[seenKey] = true end
end

-- Pull timing and instance runs (docs/design/specs/2026-11-02-pull-and-run-records-design.md). Anonymous like the
-- encounter row: times, counts and ids, never a name.
--   * ENCOUNTER_START notes the pull's start in the file (time(), so a /reload during the fight keeps it); the
--     encounter row then carries startedAt and durationSeconds. An END without its START has neither: a guessed
--     length is worse than none.
--   * A run starts when you zone into a dungeon or raid and ends when you are gone from it for 30 minutes, enter
--     another instance, the game says it was reset (CHAT_MSG_SYSTEM, the game's own INSTANCE_RESET_SUCCESS line,
--     never a player's chat), or a boss the run already killed is pulled again. A corpse run, a reload or a trip out
--     to a vendor does not end it. A run with no boss pull writes nothing; one with pulls writes one instance_run row.
--     A run still open when you stop playing is written at the next loading screen after the 30 minutes. The 30
--     minutes count only from leaving: time spent inside, however long, never ends the run.
--   * All of this, and the pulls module, waits on E.RUN_RECORDS (core.lua): off, this file listens to neither
--     ENCOUNTER_START nor CHAT_MSG_SYSTEM and writes encounter rows exactly as before.
local RUN_GAP = 1800
local MAX_PULL_SECONDS = 86400

local function iso(t) return date("!%Y-%m-%dT%H:%M:%SZ", t) end

-- Four 16-bit pieces: Lua 5.1 takes math.random's bounds as ints, so a range up to 0x7fffffff overflows and comes back negative.
local function newRunId()
  local r = math.random
  return string.format("%04x%04x%04x%04x", r(0, 0xffff), r(0, 0xffff), r(0, 0xffff), r(0, 0xffff))
end

local function finishRun(reason)
  local run = EverlootDB.run
  EverlootDB.run = nil
  if type(run) ~= "table" or type(run.pulls) ~= "number" or run.pulls < 1 or type(run.enteredAt) ~= "number" then return end
  local leftAt = math.max(run.leftAt or run.lastSeen or run.enteredAt, run.enteredAt)
  E:Store("instance_run", {
    installId = EverlootDB.installId, capturedAt = iso(leftAt),
    runId = run.id, instanceMapId = run.instanceMapId, name = run.name, instanceType = run.instanceType,
    difficulty = run.difficulty, enteredAt = iso(run.enteredAt), leftAt = iso(leftAt),
    firstPullAt = run.firstPull and iso(run.firstPull), lastKillAt = run.lastKill and iso(run.lastKill),
    pulls = run.pulls, kills = run.kills, wipes = run.wipes, size = run.size,
    killedEncounterIds = #run.killed > 0 and run.killed or nil, endReason = reason,
  })
end

--- PLAYER_ENTERING_WORLD: start, continue, pause or end the run.
local function runWorld()
  if not E.RUN_RECORDS then return end
  local now = time()
  local info = instanceInfo()
  local mapId = info and (info.instanceType == "party" or info.instanceType == "raid") and whole(info.instanceMapId, 1, MAX_ID)
  local run = type(EverlootDB.run) == "table" and EverlootDB.run or nil
  if run then
    -- Only time outside counts: a long stay inside followed by a /reload or a relog there is the same run.
    local away = run.leftAt and now - run.leftAt or 0
    if mapId and mapId == run.instanceMapId and run.difficulty == whole(info.difficulty, 0, 255) and away <= RUN_GAP then
      run.leftAt, run.lastSeen = nil, now
      return
    end
    if not mapId and away <= RUN_GAP then
      run.leftAt = run.leftAt or now
      return
    end
    finishRun(mapId and "new_instance" or "left")
  end
  if not mapId then return end
  local name = info.name
  EverlootDB.run = {
    id = newRunId(), instanceMapId = mapId, instanceType = info.instanceType, difficulty = whole(info.difficulty, 0, 255),
    name = type(name) == "string" and name ~= "" and #name <= 120 and name or nil,
    enteredAt = now, lastSeen = now, pulls = 0, kills = 0, wipes = 0, killed = {},
  }
end

--- The run a pull in this instance belongs to. A boss the run already killed, pulled again, means the instance was
--- reset without a line the addon could read: that run ends and a new one starts.
local function runFor(instanceMapId, encounterId)
  local run = EverlootDB.run
  if type(run) ~= "table" or run.instanceMapId ~= instanceMapId or run.leftAt then return nil end
  for _, id in ipairs(run.killed) do
    if id == encounterId then
      finishRun("reset")
      runWorld()
      return EverlootDB.run
    end
  end
  return run
end

--- CHAT_MSG_SYSTEM: the game's "<instance> has been reset." for the run you left ends it.
local function runReset(text)
  if not E.RUN_RECORDS then return end
  local run = EverlootDB.run
  text = E.Readable(text)
  if type(run) ~= "table" or not run.leftAt or not run.name or type(text) ~= "string" or type(INSTANCE_RESET_SUCCESS) ~= "string" then return end
  if text == INSTANCE_RESET_SUCCESS:format(run.name) then finishRun("reset") end
end

--- The run's id while you are inside it; nil outside. The pulls module puts it on its rows.
function E.CurrentRunId()
  local run = EverlootDB and EverlootDB.run
  return type(run) == "table" and not run.leftAt and run.id or nil
end

-- ENCOUNTER_START: encounterID, encounterName, difficultyID, groupSize. Only the start time is kept.
local function encounterStart(encounterId)
  if not E.RUN_RECORDS then return end
  encounterId = whole(encounterId, 1, MAX_ID)
  if not encounterId then return end
  local info = instanceInfo()
  if not info or (info.instanceType ~= "party" and info.instanceType ~= "raid") then return end
  local instanceMapId = whole(info.instanceMapId, 1, MAX_ID)
  if not instanceMapId then return end
  local now = time()
  EverlootDB.pullStart = { encounterId = encounterId, at = now }
  local run = runFor(instanceMapId, encounterId)
  if run then run.firstPull = run.firstPull or now; run.lastSeen = now end
end

-- ENCOUNTER_END inside a dungeon or raid: encounterID, encounterName, difficultyID, groupSize, success (1 a kill, 0 a wipe) and, on clients
-- that send it, the boss units engaged, each with a creatureID.
local function encounterEnd(encounterId, name, difficulty, size, success, units)
  encounterId = whole(encounterId, 1, MAX_ID)
  if success == 1 then success = true elseif success == 0 then success = false end
  if not encounterId or type(name) ~= "string" or name == "" or #name > 120 or type(success) ~= "boolean" then return end
  local info = instanceInfo()
  if not info or (info.instanceType ~= "party" and info.instanceType ~= "raid") then return end
  local instanceMapId = whole(info.instanceMapId, 1, MAX_ID)
  if not instanceMapId then return end
  local npcIds, seen = {}, {}
  if type(units) == "table" then
    for _, unit in ipairs(units) do
      local npcId = type(unit) == "table" and whole(unit.creatureID, 1, MAX_ID)
      if npcId and not seen[npcId] and #npcIds < 40 then seen[npcId] = true; npcIds[#npcIds + 1] = npcId end
    end
  end
  local now = time()
  size = whole(size, 1, 40)
  local startedAt, run
  if E.RUN_RECORDS then
    local start = EverlootDB.pullStart
    EverlootDB.pullStart = nil
    if type(start) == "table" and start.encounterId == encounterId and type(start.at) == "number"
      and now >= start.at and now - start.at <= MAX_PULL_SECONDS then
      startedAt = start.at
    end
    run = runFor(instanceMapId, encounterId)
    if run then
      run.pulls = run.pulls + 1
      run.lastSeen = now
      run.firstPull = run.firstPull or startedAt or now
      if size and size > (run.size or 0) then run.size = size end
      if success then
        run.kills = run.kills + 1
        run.lastKill = now
        if #run.killed < 40 then run.killed[#run.killed + 1] = encounterId end
      else
        run.wipes = run.wipes + 1
      end
    end
  end
  E:Store("encounter", {
    installId = EverlootDB.installId,
    capturedAt = date("!%Y-%m-%dT%H:%M:%SZ"),
    encounterId = encounterId, name = name, instanceMapId = instanceMapId, success = success,
    difficulty = whole(difficulty, 0, 255), size = size,
    npcIds = #npcIds > 0 and npcIds or nil,
    startedAt = startedAt and iso(startedAt), durationSeconds = startedAt and now - startedAt,
    runId = run and run.id,
  })
end

--- A merchant slot's price and stock. Older clients have GetMerchantItemInfo; Forever's merchant window reads
--- C_MerchantFrame.GetItemInfo, which returns them as fields.
local function merchantPrice(index)
  if GetMerchantItemInfo then
    local ok, _, _, price, _, stock = pcall(GetMerchantItemInfo, index)
    if ok then return price, stock end
    return nil
  end
  local ok, info = pcall(C_MerchantFrame.GetItemInfo, index)
  info = ok and E.Readable(info)
  if type(info) ~= "table" then return nil end
  return E.Readable(info.price), E.Readable(info.numAvailable)
end

local function vendorCapture()
  local canPrice = GetMerchantItemInfo or (C_MerchantFrame and C_MerchantFrame.GetItemInfo)
  if not GetMerchantNumItems or not GetMerchantItemLink or not canPrice then return end
  local vendorNpcId = npcIdFromGuid(UnitGUID("npc")) or npcIdFromGuid(UnitGUID("target"))
  if not vendorNpcId then return end
  local okCount, count = pcall(GetMerchantNumItems)
  if not okCount or type(count) ~= "number" or count < 1 then return end
  local items = {}
  for i = 1, math.min(count, 200) do
    local okLink, link = pcall(GetMerchantItemLink, i)
    local itemId = okLink and type(link) == "string" and tonumber(link:match("item:(%d+)"))
    if itemId then
      local price, stock = merchantPrice(i)
      if type(price) == "number" and price >= 0 and price == math.floor(price) then
        local row = { itemId = itemId, priceCopper = price }
        if type(stock) == "number" and stock > 0 and stock == math.floor(stock) then
          row.limitedStock = stock
        end
        items[#items + 1] = row
        rememberItem(itemId)
      end
    end
  end
  if #items == 0 then return end
  -- One row per vendor and UTC day: opening the same window again adds nothing unless an item, a price or a
  -- limited stock changed. The hash is of the items as read, in the vendor's order.
  EverlootDB.vendorSeen = EverlootDB.vendorSeen or {}
  local parts = {}
  for i, item in ipairs(items) do parts[i] = item.itemId .. ":" .. item.priceCopper .. ":" .. (item.limitedStock or "") end
  local day, hash = date("!%Y-%m-%d"), E.Adler32(table.concat(parts, ","))
  local seen = EverlootDB.vendorSeen[vendorNpcId]
  if type(seen) == "table" and seen.day == day and seen.hash == hash then return end
  local stored = E:Store("vendor", {
    installId = EverlootDB.installId,
    capturedAt = date("!%Y-%m-%dT%H:%M:%SZ"),
    vendorNpcId = vendorNpcId,
    items = items,
  })
  if stored then EverlootDB.vendorSeen[vendorNpcId] = { day = day, hash = hash } end
end

-- Names of the sources this install has met, as this client showed them: NPCs from its sightings, objects from its
-- sightings and from what it looted. Read from the rows already in the saved file, never written to it; each lookup
-- reads only the rows stored since the last one. A source this install never met has no name here.
local known = { npc = {}, object = {}, read = {} }
local NAME_ROWS = {
  { kind = "npc_sighting", id = "npcId", name = "name", into = "npc" },
  { kind = "object_sighting", id = "objectId", name = "name", into = "object" },
  { kind = "loot", id = "sourceObjectId", name = "sourceObjectName", into = "object" },
}

--- The name this install saw for a drop source (modules/drops.lua shows it) ("npc" or "object" and its id), or nil.
function E:SourceName(kind, id)
  local records = type(EverlootDB) == "table" and EverlootDB.records
  if type(records) ~= "table" then return nil end
  for _, source in ipairs(NAME_ROWS) do
    local rows = records[source.kind]
    if type(rows) == "table" then
      local from = known.read[source.kind] or 0
      if #rows < from then from = 0 end -- the rows were cleared: read them again
      local into = known[source.into]
      for i = from + 1, #rows do
        local row = rows[i]
        local rowId, name = type(row) == "table" and row[source.id], type(row) == "table" and row[source.name]
        if type(rowId) == "number" and type(name) == "string" and name ~= "" then into[rowId] = name end
      end
      known.read[source.kind] = #rows
    end
  end
  local name = known[kind] and known[kind][id]
  -- A name is shown as written: a pipe would start a colour or texture escape.
  return name and (name:gsub("|", "||")) or nil
end

-- A Lua error in one handler on the shared frame ends the dispatch, so the modules after it miss the event.
-- The captures that read the game's own windows run inside this, and the first error of a session is said once.
local failedOnce, failedFns = false, {}
local function guarded(label, fn, ...)
  local ok, err = pcall(fn, ...)
  if ok or failedFns[label] then return end
  failedFns[label] = true
  E:SetNote("openworld", "error in " .. label .. ": " .. tostring(err))
  if failedOnce then return end
  failedOnce = true
  print("Everloot: openworld hit an error and keeps running. Other modules are not affected. /everloot status says more.")
end

E:RegisterModule("openworld", function()
  local f = E.frame
  f:RegisterEvent("PLAYER_TARGET_CHANGED")
  f:RegisterEvent("UPDATE_MOUSEOVER_UNIT")
  f:RegisterEvent("LOOT_OPENED")
  pcall(function() f:RegisterEvent("QUEST_ACCEPTED") end)
  -- MERCHANT_SHOW is an old client event. A missing event disables the hook.
  pcall(function() f:RegisterEvent("MERCHANT_SHOW") end)
  -- 0.3.7 and earlier paused a whole kind; these kinds now pause one share at a time.
  if EverlootDB.paused then EverlootDB.paused.npc_sighting, EverlootDB.paused.loot = nil, nil end
  for event in pairs(WINDOW_ROLES) do pcall(function() f:RegisterEvent(event) end) end
  for _, event in ipairs({ "PLAYER_INTERACTION_MANAGER_FRAME_SHOW", "LOOT_CLOSED", "VIGNETTE_MINIMAP_UPDATED", "VIGNETTES_UPDATED", "PLAYER_LEAVING_WORLD",
    "PLAYER_ENTERING_WORLD", "ENCOUNTER_END" }) do
    pcall(function() f:RegisterEvent(event) end)
  end
  if E.RUN_RECORDS then
    for _, event in ipairs({ "ENCOUNTER_START", "CHAT_MSG_SYSTEM" }) do pcall(function() f:RegisterEvent(event) end) end
  end
  local function onEvent(_, event, arg1, arg2, arg3, arg4, arg5, arg6)
    if event == "PLAYER_TARGET_CHANGED" then guarded("targetSighting", targetSighting, "target")
    elseif event == "UPDATE_MOUSEOVER_UNIT" then guarded("targetSighting", targetSighting, "mouseover")
    elseif event == "LOOT_OPENED" then guarded("lootCapture", lootCapture, arg1, arg2)
    elseif event == "QUEST_ACCEPTED" then guarded("questCapture", questCapture, arg1, arg2)
    elseif event == "UNIT_SPELLCAST_SENT" then pcall(castSent, arg1, arg2, arg3, arg4)
    elseif (event == "UNIT_SPELLCAST_FAILED" or event == "UNIT_SPELLCAST_FAILED_QUIET" or event == "UNIT_SPELLCAST_INTERRUPTED")
      and arg1 == "player" then
      if pendingCast(arg2) then lastCast = nil end
    elseif event == "UNIT_SPELLCAST_SUCCEEDED" and arg1 == "player" then
      if pendingCast(arg2) then lastCast.succeeded = true end
    elseif event == "LOOT_CLOSED" then lastCast = nil
    elseif event == "VIGNETTE_MINIMAP_UPDATED" then if arg2 then pcall(vignetteSighting, arg1) end
    elseif event == "VIGNETTES_UPDATED" then pcall(vignettesUpdated)
    elseif event == "PLAYER_LEAVING_WORLD" then pcall(leavingWorld)
    elseif event == "PLAYER_ENTERING_WORLD" then pcall(enteringWorld); pcall(runWorld)
    elseif event == "ENCOUNTER_START" then pcall(encounterStart, arg1)
    elseif event == "ENCOUNTER_END" then pcall(encounterEnd, arg1, arg2, arg3, arg4, arg5, arg6)
    elseif event == "CHAT_MSG_SYSTEM" then pcall(runReset, arg1)
    elseif event == "PLAYER_INTERACTION_MANAGER_FRAME_SHOW" then
      local role = interactionRole(arg1)
      if role ~= nil then pcall(interactionSighting, role or nil) end
    end
    if event == "MERCHANT_SHOW" then guarded("vendorCapture", vendorCapture) end
    local role = WINDOW_ROLES[event]
    if role == false then
      local ok, found = pcall(gossipRole)
      role = ok and found or false
    end
    if role ~= nil then pcall(interactionSighting, role or nil) end
  end
  f:HookScript("OnEvent", onEvent)
  -- Spell casts are the player's own only: a frame of its own, so they do not run through every module's handler.
  local spellFrame = CreateFrame("Frame")
  for _, event in ipairs({ "UNIT_SPELLCAST_SENT", "UNIT_SPELLCAST_FAILED", "UNIT_SPELLCAST_FAILED_QUIET",
    "UNIT_SPELLCAST_SUCCEEDED", "UNIT_SPELLCAST_INTERRUPTED" }) do
    if spellFrame.RegisterUnitEvent then pcall(spellFrame.RegisterUnitEvent, spellFrame, event, "player")
    else pcall(spellFrame.RegisterEvent, spellFrame, event) end
  end
  spellFrame:SetScript("OnEvent", onEvent)
  if not canReadQuestLog() then
    return "ready (target/mouseover/loot/merchant/NPC windows; quests off, this client has no quest log reader)"
  end
  return "ready (target/mouseover/loot/merchant/NPC windows/quest accept)"
end)
